import Vue from 'vue';
import DownloadSeq2Seq from '../components/download_seq2seq.vue';

new Vue({
  el: '#mail-app',

  components: { DownloadSeq2Seq },

  template: '<DownloadSeq2Seq />',
});
