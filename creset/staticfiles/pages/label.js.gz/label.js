import Vue from 'vue';
import Labels from '../components/label.vue';

new Vue({
  el: '#mail-app',

  components: { Labels },

  template: '<Labels />',
});
