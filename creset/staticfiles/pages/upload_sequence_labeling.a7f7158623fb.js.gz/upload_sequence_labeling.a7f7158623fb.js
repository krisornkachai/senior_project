import Vue from 'vue';
import UploadSequenceLabeling from '../components/upload_sequence_labeling.vue';

new Vue({
  el: '#mail-app',

  components: { UploadSequenceLabeling },

  template: '<UploadSequenceLabeling />',
});
