import Vue from 'vue';
import UploadSeq2Seq from '../components/upload_seq2seq.vue';

new Vue({
  el: '#mail-app',

  components: { UploadSeq2Seq },

  template: '<UploadSeq2Seq />',
});
