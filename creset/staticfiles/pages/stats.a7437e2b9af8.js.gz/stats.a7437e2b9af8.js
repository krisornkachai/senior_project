import Vue from 'vue';
import Stats from '../components/stats.vue';

new Vue({
  el: '#mail-app',

  components: { Stats },

  template: '<Stats />',
});
