import document from './document';
import window from './window';

export { window, document };
