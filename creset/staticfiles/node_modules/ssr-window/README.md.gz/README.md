# SSR Window

Better handling for `window` object in SSR environment.

Was created for use in:

* [Dom7](https://github.com/nolimits4web/dom7)
* [Swiper](https://github.com/nolimits4web/swiper)
* [Framework7](https://github.com/framework7io/framework7)
