# Clock Pug coding standard

## Usage

In your project folder:

```
npm install --save-dev pug-lint
npm install --save-dev pug-lint-config-clock
```

Then create a `.pug-lintrc` in the project root.

```json
{ "extends": "clock"
}
```
