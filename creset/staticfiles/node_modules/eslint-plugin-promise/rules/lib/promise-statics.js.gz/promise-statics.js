'use strict'

module.exports = {
  all: true,
  race: true,
  reject: true,
  resolve: true
}
