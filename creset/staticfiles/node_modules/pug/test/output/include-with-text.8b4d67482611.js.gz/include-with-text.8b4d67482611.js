function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><head><script type="text/javascript">alert(\'hello world\');</script><script src="/caustic.js"></script><script src="/app.js"></script></head></html>';
    return pug_html;
}