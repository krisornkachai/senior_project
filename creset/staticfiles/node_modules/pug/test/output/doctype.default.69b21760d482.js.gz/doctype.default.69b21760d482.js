function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<!DOCTYPE html><html><body><h1>Title</h1></body></html>";
    return pug_html;
}