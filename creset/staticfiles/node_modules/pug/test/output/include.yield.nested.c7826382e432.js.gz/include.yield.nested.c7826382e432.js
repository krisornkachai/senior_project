function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><head><title></title></head><body><h1>Page</h1><div id="content"><div id="content-wrapper"><p>some content</p><p>and some more</p></div></div><div id="footer"><stuff></stuff></div></body></html>';
    return pug_html;
}