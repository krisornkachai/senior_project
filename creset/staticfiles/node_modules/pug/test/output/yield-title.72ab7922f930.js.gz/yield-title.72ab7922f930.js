function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><body><head><title>My Title</title><script src="/jquery.js"></script><script src="/jquery.ui.js"></script></head></body></html>';
    return pug_html;
}