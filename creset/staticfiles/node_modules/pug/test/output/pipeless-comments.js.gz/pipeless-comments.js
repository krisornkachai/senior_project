function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<!--     .foo\n\t.bar\n.hey-->";
    return pug_html;
}