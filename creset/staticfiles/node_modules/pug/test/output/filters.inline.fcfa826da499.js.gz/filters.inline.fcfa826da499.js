function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<p>before <![CDATA[inside]]> after</p>";
    return pug_html;
}