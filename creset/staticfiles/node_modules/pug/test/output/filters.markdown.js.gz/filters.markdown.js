function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<html><body><p>This is <em>some</em> awesome <strong>markdown</strong>\nwhoop.</p>\n</body></html>";
    return pug_html;
}