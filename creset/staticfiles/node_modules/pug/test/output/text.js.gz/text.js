function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<option value="">-- (selected) --</option><p></p><p></p><p>foo\nbar\n\n\nbaz</p><p>foo\n\n\nbar\nbaz\n</p>foo\n\n\nbar\nbaz\n<pre>foo\n  bar\n    baz\n.</pre><pre>foo\n  bar\n    baz\n.\n</pre>foo\n  bar\n    baz\n.';
    return pug_html;
}