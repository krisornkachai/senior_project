function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<ul><li>foo</li><li>bar</li><li>baz</li></ul>";
    return pug_html;
}