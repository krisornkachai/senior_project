function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<script type="text/javascript">(function() {\n  var regexp;\n\n  regexp = /\\n/;\n\n}).call(this);\n(function(){}).call(this);</script>';
    return pug_html;
}