function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><body><p>The message is "<em>hello world</em>"</p></body></html>';
    return pug_html;
}