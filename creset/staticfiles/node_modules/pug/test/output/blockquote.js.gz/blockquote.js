function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<figure><blockquote>Try to define yourself by what you do, and you&#8217;ll burnout every time. You are. That is enough. I rest in that.</blockquote><figcaption>from @thefray at 1:43pm on May 10</figcaption></figure>";
    return pug_html;
}