function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<html><head><title>My Application</title></head><body><h1>hello</h1></body></html>";
    return pug_html;
}