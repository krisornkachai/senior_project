function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<!DOCTYPE html><html><head><title>Default title</title></head><body><h1>Page 2</h1></body></html>";
    return pug_html;
}