function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<fb:user:role>Something</fb:user:role><foo fb:foo="bar"></foo>';
    return pug_html;
}