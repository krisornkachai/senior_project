function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><head><script src="jquery.js"></script><script src="keymaster.js"></script><script src="caustic.js"></script></head></html>';
    return pug_html;
}