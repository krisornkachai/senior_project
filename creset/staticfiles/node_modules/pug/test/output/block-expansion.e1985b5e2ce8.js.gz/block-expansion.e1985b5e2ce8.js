function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<ul><li><a href="#">foo</a></li><li><a href="#">bar</a></li></ul><p>baz</p>';
    return pug_html;
}