function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<head><script type=\"text/javascript\">alert('hello world');</script></head>";
    return pug_html;
}