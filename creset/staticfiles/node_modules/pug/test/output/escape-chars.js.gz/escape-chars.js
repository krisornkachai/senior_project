function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<script>var re = /\\d+/;</script>";
    return pug_html;
}