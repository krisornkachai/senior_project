function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<pre><code>var x = "\\n here is some \\n new lined text";\n</code></pre>';
    return pug_html;
}