function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<pre><code>code sample\n</code></pre>\n<h1>Heading</h1>\n";
    return pug_html;
}