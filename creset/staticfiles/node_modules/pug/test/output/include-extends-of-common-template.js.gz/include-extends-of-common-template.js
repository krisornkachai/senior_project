function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<div>test1</div><div>test2</div>";
    return pug_html;
}