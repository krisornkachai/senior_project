function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<h1>grand-grandparent</h1><h2>grandparent</h2><h3>parent</h3><h4>child</h4>";
    return pug_html;
}