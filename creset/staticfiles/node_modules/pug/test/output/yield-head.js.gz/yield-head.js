function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<head><script src="/jquery.js"></script><script src="/jquery.ui.js"></script></head>';
    return pug_html;
}