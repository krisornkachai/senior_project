function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><head><title>My Application</title><script src="jquery.js"></script></head><body><h2>Page</h2><p>Some content</p></body></html>';
    return pug_html;
}