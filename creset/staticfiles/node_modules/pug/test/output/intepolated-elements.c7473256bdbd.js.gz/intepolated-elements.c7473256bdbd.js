function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<p><a class="rho rho--modifier" href="#">with inline link</a></p><p>Some text <a class="rho rho--modifier" href="#"></a></p><p>Some text <a class="rho rho--modifier" href="#">with inline link</a></p>';
    return pug_html;
}