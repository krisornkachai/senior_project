function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<?xml version="1.0" encoding="utf-8" ?><category term="some term"/><link>http://google.com</link>';
    return pug_html;
}