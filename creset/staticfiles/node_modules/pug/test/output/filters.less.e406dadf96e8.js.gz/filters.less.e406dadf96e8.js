function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<html><head><style type="text/css">body {\n  padding: 15px;\n}\n</style></head></html>';
    return pug_html;
}