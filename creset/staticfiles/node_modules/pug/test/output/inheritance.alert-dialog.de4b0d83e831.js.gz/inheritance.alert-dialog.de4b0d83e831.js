function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<div class="window"><a class="close" href="#">Close</a><div class="dialog"><h1>Alert!</h1><p>I\'m an alert!</p></div></div>';
    return pug_html;
}