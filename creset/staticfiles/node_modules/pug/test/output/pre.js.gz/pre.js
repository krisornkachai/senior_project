function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<pre>foo\nbar\nbaz\n</pre><pre><code>foo\nbar\nbaz</code></pre>";
    return pug_html;
}