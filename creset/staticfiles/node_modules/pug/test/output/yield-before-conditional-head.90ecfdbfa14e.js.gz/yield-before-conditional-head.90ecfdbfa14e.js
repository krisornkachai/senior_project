function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<head><script src="/jquery.js"></script>';
    if (false) {
        pug_html = pug_html + '<script src="/jquery.ui.js"></script>';
    }
    pug_html = pug_html + "</head>";
    return pug_html;
}