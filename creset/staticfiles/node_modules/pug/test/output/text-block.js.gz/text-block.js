function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<label>Username:<input type="text" name="user[name]"/></label><label>Password:<input type="text" name="user[pass]"/></label>';
    return pug_html;
}