function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<!DOCTYPE html><html><body><br/></body></html>";
    return pug_html;
}