function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + "<!DOCTYPE custom stuff>";
    return pug_html;
}