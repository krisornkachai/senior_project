function template(locals) {
    var pug_html = "", pug_mixins = {}, pug_interp;
    pug_html = pug_html + '<ul><li class="list-item"><div class="foo"><div id="bar">baz</div></div></li></ul>';
    return pug_html;
}