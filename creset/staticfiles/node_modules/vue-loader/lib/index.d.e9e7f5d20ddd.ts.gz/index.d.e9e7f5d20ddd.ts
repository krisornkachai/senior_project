import { Plugin } from 'webpack'

declare namespace VueLoader {
  class VueLoaderPlugin extends Plugin {}
}

export = VueLoader
