import Swatches from './Swatches'

export default Swatches
export { Swatches }
