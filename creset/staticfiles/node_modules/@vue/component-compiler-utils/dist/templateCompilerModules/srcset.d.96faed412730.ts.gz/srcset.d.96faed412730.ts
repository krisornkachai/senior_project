import { ASTNode } from './utils';
declare const _default: () => {
    postTransformNode: (node: ASTNode) => void;
};
export default _default;
