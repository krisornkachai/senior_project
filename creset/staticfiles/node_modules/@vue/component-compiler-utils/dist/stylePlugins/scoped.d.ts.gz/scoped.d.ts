import * as postcss from 'postcss';
declare const _default: postcss.Plugin<any>;
export default _default;
