import * as postcss from 'postcss';
declare const _default: postcss.Plugin<{}>;
export default _default;
