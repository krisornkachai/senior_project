# Change Log

This project follows [Semantic Versioning](http://semver.org/).
Every release is documented on the GitHub [Releases](https://github.com/ctimmerm/axios-mock-adapter/releases) page.
