"use strict";

var isImplemented = require("../../../../array/#/@@iterator/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
