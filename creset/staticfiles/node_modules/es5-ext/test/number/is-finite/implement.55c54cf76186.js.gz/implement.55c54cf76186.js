"use strict";

var isImplemented = require("../../../number/is-finite/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
