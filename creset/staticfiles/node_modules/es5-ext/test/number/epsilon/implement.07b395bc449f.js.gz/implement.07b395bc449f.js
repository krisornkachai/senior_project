"use strict";

var isImplemented = require("../../../number/epsilon/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
