"use strict";

var isImplemented = require("../../../../reg-exp/#/split/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
