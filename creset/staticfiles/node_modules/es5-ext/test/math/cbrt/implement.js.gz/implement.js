"use strict";

var isImplemented = require("../../../math/cbrt/is-implemented");

module.exports = function (a) {
 a(isImplemented(), true);
};
